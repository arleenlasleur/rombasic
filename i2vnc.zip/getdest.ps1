$wc = New-Object Net.WebClient
$text=$wc.DownloadString('http://127.0.0.1:7070/?page=i2p_tunnels')
$i=$text.LastIndexOf("VNC_IN")+19
$j=$text.LastIndexOf("5900")-9
$text.SubString($i,$j-$i)

